//
//  toubApp.swift
//  toub
//
//  Created by Norah Asaker on 13/06/1445 AH.
//

import SwiftUI

@main
struct toubApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
